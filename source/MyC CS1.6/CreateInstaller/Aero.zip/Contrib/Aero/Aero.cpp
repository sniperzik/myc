#include <windows.h>
#include "aero.h"

#ifdef UNICODE
#include "nsis_unicode\pluginapi.h"
#else
#include "nsis_ansi\pluginapi.h"
#endif

HANDLE  g_hInstance;
HWND    g_hWndParent, g_hBack, g_hNext, g_hCancel;
WNDPROC ParentDlgProcOld;
MARGINS g_margins;
RECT    g_rectAero, g_rectWindow;
RECT    g_rect1028, g_rect1035, g_rect1045, g_rect1256;
HBRUSH  g_hbAero;
PWCHAR  g_pwcBrandingText;
HFONT   g_hFont;
HTHEME  g_hButtonTheme, g_hWindowTheme;
int     g_iBrandingLeft;

static UINT_PTR PluginCallback(enum NSPIM msg)
{
  if (msg == NSPIM_GUIUNLOAD)
  {
    DeleteObject(g_hbAero);
    CloseThemeData(g_hButtonTheme);
    if (g_hWindowTheme != NULL)
      CloseThemeData(g_hWindowTheme);
    if (g_pwcBrandingText != NULL)
      GlobalFree(g_pwcBrandingText);
    BufferedPaintUnInit();
  }
  return 0;
}

BOOL CALLBACK ParentDlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  switch (uMsg)
  {
  case WM_THEMECHANGED:

    CloseThemeData(g_hButtonTheme);
    g_hButtonTheme = OpenThemeData(hWnd, L"Button");

    if (g_hWindowTheme != NULL)
    {
      CloseThemeData(g_hWindowTheme);
      g_hWindowTheme = OpenThemeData(hWnd, L"CompositedWindow::Window");
    }

    return FALSE;

  case WM_DWMCOMPOSITIONCHANGED:

    BOOL fAero;
    HWND hWndCtl;
    if (SUCCEEDED(DwmIsCompositionEnabled(&fAero)) && fAero)
    {
      g_hbAero = CreateSolidBrush(COLOR_AERO);
      DwmExtendFrameIntoClientArea(hWnd, &g_margins);
      
      hWndCtl = GetDlgItem(hWnd, -1);
      if (IsWindow(hWndCtl))
      {
        ShowWindow(hWndCtl, SW_HIDE);
        ShowWindow(GetDlgItem(hWnd, 1028), SW_HIDE);
      }
      else
      {
        hWndCtl = GetDlgItem(hWnd, 1028);
        if (IsWindow(hWndCtl))
          SetWindowPos(hWndCtl, 0, 0, g_rectAero.bottom + 1, 0, 0, SWP_NOSIZE | SWP_NOZORDER);

        hWndCtl = GetDlgItem(hWnd, 1035);
        if (IsWindow(hWndCtl))
          SetWindowPos(hWndCtl, 0, 0, g_rectAero.bottom + 1, 0, 0, SWP_NOSIZE | SWP_NOZORDER);

        hWndCtl = GetDlgItem(hWnd, 1045);
        if (IsWindow(hWndCtl))
          SetWindowPos(hWndCtl, 0, 0, g_rectAero.bottom + 1, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
    
        hWndCtl = GetDlgItem(hWnd, 1256);
        if (IsWindow(hWndCtl))
          SetWindowPos(hWndCtl, 0, 0, g_rectAero.bottom + 1, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
      }
    }
    else
    {
      DeleteObject(g_hbAero);
      g_hbAero = NULL;
      
      hWndCtl = GetDlgItem(hWnd, -1);
      if (IsWindow(hWndCtl))
      {
        ShowWindow(hWndCtl, SW_SHOW);
        ShowWindow(GetDlgItem(hWnd, 1028), SW_SHOW);
      }
      else
      {
        hWndCtl = GetDlgItem(hWnd, 1028);
        if (IsWindow(hWndCtl))
          SetWindowPos(hWndCtl, 0, g_rect1028.left, g_rect1028.top, 0, 0, SWP_NOSIZE | SWP_NOZORDER);

        hWndCtl = GetDlgItem(hWnd, 1035);
        if (IsWindow(hWndCtl))
          SetWindowPos(hWndCtl, 0, g_rect1035.left, g_rect1035.top, 0, 0, SWP_NOSIZE | SWP_NOZORDER);

        hWndCtl = GetDlgItem(hWnd, 1045);
        if (IsWindow(hWndCtl))
          SetWindowPos(hWndCtl, 0, g_rect1045.left, g_rect1045.top, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
    
        hWndCtl = GetDlgItem(hWnd, 1256);
        if (IsWindow(hWndCtl))
          SetWindowPos(hWndCtl, 0, g_rect1256.left, g_rect1256.top, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
      }
    }

    return FALSE;

  case WM_NOTIFY_OUTER_NEXT:

    if (g_hbAero != NULL)
    {
      InvalidateRect(g_hCancel, NULL, TRUE);
      InvalidateRect(g_hBack, NULL, TRUE);
      InvalidateRect(g_hNext, NULL, TRUE);
    }

    break;

  case WM_ERASEBKGND:

    if (g_hbAero == NULL)
      break;

    FillRect((HDC)wParam, &g_rectWindow, GetSysColorBrush(COLOR_BTNFACE));
    FillRect((HDC)wParam, &g_rectAero, g_hbAero);
    
    if (g_pwcBrandingText != NULL)
    {
      HDC hDC = CreateCompatibleDC((HDC)wParam);
      if (SaveDC(hDC) != 0)
      {
        BITMAPINFO dib;
        dib.bmiHeader.biSize = sizeof(BITMAPINFO);
        dib.bmiHeader.biHeight = -g_margins.cyBottomHeight;
        dib.bmiHeader.biWidth = g_rectWindow.right;
        dib.bmiHeader.biPlanes = 1;
        dib.bmiHeader.biBitCount = 32;
        dib.bmiHeader.biCompression = BI_RGB;

        HBITMAP hBitmap = CreateDIBSection((HDC)wParam, &dib, DIB_RGB_COLORS, NULL, NULL, 0);
        if (hBitmap != NULL)
        {
          DTTOPTS dto;
          dto.dwSize = sizeof(DTTOPTS);
          dto.dwFlags = DTT_TEXTCOLOR | DTT_GLOWSIZE | DTT_COMPOSITED;
          dto.crText = GetThemeSysColor(g_hWindowTheme, COLOR_WINDOWTEXT);
          dto.iGlowSize = 12;

          GetThemeInt(g_hWindowTheme, 0, 0, TMT_TEXTGLOWSIZE, &dto.iGlowSize);

          RECT r;
          r.left = g_iBrandingLeft;
          r.top = 0;
          r.right = g_rectWindow.right - g_iBrandingLeft;
          r.bottom = g_margins.cyBottomHeight;

          HBITMAP hBitmapOld = (HBITMAP)SelectObject(hDC, hBitmap);
          HFONT hFontOld = (HFONT)SelectObject(hDC, g_hFont);

          DrawThemeTextEx(g_hWindowTheme, hDC, 0, 0, g_pwcBrandingText, -1, DT_SINGLELINE | DT_VCENTER | DT_NOPREFIX, &r, &dto);

          BitBlt((HDC)wParam, 0, g_rectAero.top, g_rectWindow.right, g_margins.cyBottomHeight, hDC, 0, 0, SRCCOPY | CAPTUREBLT);

          SelectObject(hDC, hBitmapOld);
          SelectObject(hDC, hFontOld);
          DeleteObject(hBitmap);
        }
        
        RestoreDC((HDC)wParam, -1);
        DeleteDC(hDC);
      }
    }

    return TRUE;

  case WM_CTLCOLORBTN:

    if (g_hbAero == NULL || ((HWND)lParam != g_hBack && (HWND)lParam != g_hNext && (HWND)lParam != g_hCancel))
      break;
    return (LRESULT)g_hbAero;
  }

  return CallWindowProc(ParentDlgProcOld, hWnd, uMsg, wParam, lParam);
}

BOOL CALLBACK ButtonWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  switch (uMsg)
  {
  case WM_ENABLE:
  case WM_SHOWWINDOW:
    
    if (g_hbAero != NULL)
    {
      InvalidateRect(hWnd, NULL, TRUE);
    }

    return FALSE;

  case WM_SETTEXT:
    
    if (g_hbAero != NULL)
    {
      InvalidateRect(hWnd, NULL, TRUE);
    }

    break;

  case WM_PAINT:
    
    if (g_hbAero == NULL)
      break;

    PAINTSTRUCT ps;
    HDC hdcPaint = BeginPaint(hWnd, &ps);
    if (hdcPaint != NULL)
    {
      RECT r;
      GetClientRect(hWnd, &r);

      HDC hdcBufferedPaint;
      HPAINTBUFFER hBufferedPaint = BeginBufferedPaint(hdcPaint, &r, BPBF_COMPOSITED, NULL, &hdcBufferedPaint);
      if (hBufferedPaint != NULL)
      {
        SendMessage(hWnd, WM_PRINTCLIENT, (WPARAM)hdcBufferedPaint, PRF_CLIENT);
        
        RECT rContent;
        GetThemeBackgroundContentRect(g_hButtonTheme, NULL, BP_PUSHBUTTON, PBS_NORMAL, &r, &rContent);
        BufferedPaintSetAlpha(hBufferedPaint, &rContent, 255);

        EndBufferedPaint(hBufferedPaint, TRUE);
      }

      EndPaint(hWnd, &ps);
    }
    
    return FALSE;
  }
  
  return CallWindowProc((WNDPROC)GetProp(hWnd, PROP_BUTTON_WNDPROC), hWnd, uMsg, wParam, lParam);
}

NSISFUNC(Apply)
{
  EXDLL_INIT();

  // Plug-in already called?
  if (ParentDlgProcOld)
    return;

  // Not Vista or above?
  if (LOBYTE(LOWORD(GetVersion())) < 6)
    return;

  HINSTANCE hDll = LoadLibrary(TEXT("Dwmapi.dll"));
  if (hDll == NULL)
    return;
  
  DwmIsCompositionEnabled = (PDwmIsCompositionEnabled)GetProcAddress(hDll, "DwmIsCompositionEnabled");
  DwmExtendFrameIntoClientArea = (PDwmExtendFrameIntoClientArea)GetProcAddress(hDll, "DwmExtendFrameIntoClientArea");
  if (DwmIsCompositionEnabled == NULL || DwmExtendFrameIntoClientArea == NULL)
    return;

  // Check if Windows Aero is enabled.
  BOOL fAero;
  if (!SUCCEEDED(DwmIsCompositionEnabled(&fAero)))
    return;
  
  // We need some other functions from UxTheme.dll.
  hDll = LoadLibrary(TEXT("UxTheme.dll"));
  if (hDll == NULL)
    return;

  OpenThemeData = (POpenThemeData)GetProcAddress(hDll, "OpenThemeData");
  CloseThemeData = (PCloseThemeData)GetProcAddress(hDll, "CloseThemeData");
  BufferedPaintInit = (PBufferedPaintInit)GetProcAddress(hDll, "BufferedPaintInit");
  BufferedPaintUnInit = (PBufferedPaintUnInit)GetProcAddress(hDll, "BufferedPaintUnInit");
  BeginBufferedPaint = (PBeginBufferedPaint)GetProcAddress(hDll, "BeginBufferedPaint");
  EndBufferedPaint = (PEndBufferedPaint)GetProcAddress(hDll, "EndBufferedPaint");
  BufferedPaintSetAlpha = (PBufferedPaintSetAlpha)GetProcAddress(hDll, "BufferedPaintSetAlpha");
  GetThemeBackgroundContentRect = (PGetThemeBackgroundContentRect)GetProcAddress(hDll, "GetThemeBackgroundContentRect");
  if (OpenThemeData == NULL ||
      CloseThemeData == NULL ||
      BufferedPaintInit == NULL ||
      BufferedPaintUnInit == NULL ||
      BeginBufferedPaint == NULL ||
      EndBufferedPaint == NULL ||
      BufferedPaintSetAlpha == NULL ||
      GetThemeBackgroundContentRect == NULL)
    return;

  g_hButtonTheme = OpenThemeData(NULL, L"Button");
  if (g_hButtonTheme == NULL)
    return;

  BufferedPaintInit();
  
  HWND hWndBrandingText = GetDlgItem(hWndParent, 1028);
  g_pwcBrandingText = NULL;

  // Should we draw the branding text?
  PTCHAR pszParam = (PTCHAR)GlobalAlloc(GPTR, sizeof(TCHAR) * string_size);
  if (pszParam)
  {
    if (popstring(pszParam) != 0 || lstrcmpi(pszParam, TEXT("/nobranding")) != 0)
    {
      pushstring(pszParam);
      
      if (IsWindow(hWndBrandingText))
      {
        // Load extra functions used for drawing the branding text.
        DrawThemeTextEx = (PDrawThemeTextEx)GetProcAddress(hDll, "DrawThemeTextEx");
        GetThemeInt = (PGetThemeInt)GetProcAddress(hDll, "GetThemeInt");
        GetThemeSysColor = (PGetThemeSysColor)GetProcAddress(hDll, "GetThemeSysColor");
        if (DrawThemeTextEx == NULL ||
            GetThemeInt == NULL ||
            GetThemeSysColor == NULL)
          goto cleanup;

        // Get the theme to use for drawing the branding text.
        g_hWindowTheme = OpenThemeData(NULL, L"CompositedWindow::Window");
        if (g_hWindowTheme == NULL)
          goto cleanup;

        g_hFont = (HFONT)SendMessage(hWndBrandingText, WM_GETFONT, 0, 0);

#ifdef UNICODE
        g_pwcBrandingText = pszParam;
#else
        g_pwcBrandingText = (PWCHAR)GlobalAlloc(GPTR, sizeof(WCHAR) * string_size);
#endif
        GetWindowTextW(hWndBrandingText, g_pwcBrandingText, string_size);
      }
    }
#ifndef UNICODE
    GlobalFree(pszParam);
#endif
  }

  // Is MUI? (Get the MUI welcome/finish pages rect.)
  HWND hWndCtl = GetDlgItem(hWndParent, 1044);
  if (IsWindow(hWndCtl))
  {
    RECT r1, r2;
    if (!GetClientRect(hWndCtl, &r1) || !GetClientRect(hWndParent, &r2))
      goto cleanup;

    g_margins.cxLeftWidth = g_margins.cxRightWidth = g_margins.cyTopHeight = 0;
    g_margins.cyBottomHeight = r2.bottom - r1.bottom;
    g_rectAero.left = g_rectWindow.left = 0;
    g_rectAero.top = r1.bottom; g_rectWindow.top = 0;
    g_rectAero.right = g_rectWindow.right = r2.right;
    g_rectAero.bottom = r2.bottom; g_rectWindow.bottom = r1.bottom;
    
    GetWindowRect(hWndBrandingText, &g_rect1028);
    MapWindowPoints(HWND_DESKTOP, hWndParent, (LPPOINT)&g_rect1028, 2);
    if (fAero)
      SetWindowPos(hWndBrandingText, 0, 0, r2.bottom + 1, 0, 0, SWP_NOSIZE | SWP_NOZORDER);

    hWndCtl = GetDlgItem(hWndParent, 1035);
    if (IsWindow(hWndCtl))
    {
      GetWindowRect(hWndCtl, &g_rect1035);
      MapWindowPoints(HWND_DESKTOP, hWndParent, (LPPOINT)&g_rect1035, 2);
      if (fAero)
        SetWindowPos(hWndCtl, 0, 0, r2.bottom + 1, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
    }

    hWndCtl = GetDlgItem(hWndParent, 1045);
    if (IsWindow(hWndCtl))
    {
      GetWindowRect(hWndCtl, &g_rect1045);
      MapWindowPoints(HWND_DESKTOP, hWndParent, (LPPOINT)&g_rect1045, 2);
      if (fAero)
        SetWindowPos(hWndCtl, 0, 0, r2.bottom + 1, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
    }
    
    hWndCtl = GetDlgItem(hWndParent, 1256);
    if (IsWindow(hWndCtl))
    {
      GetWindowRect(hWndCtl, &g_rect1256);
      MapWindowPoints(HWND_DESKTOP, hWndParent, (LPPOINT)&g_rect1256, 2);
      if (fAero)
        SetWindowPos(hWndCtl, 0, 0, r2.bottom + 1, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
    }
  }
  else // Implement for non MUI?:
  {
    hWndCtl = GetDlgItem(hWndParent, -1);
    if (!IsWindow(hWndCtl))
      goto cleanup;

    RECT r1, r2;
    if (!GetWindowRect(hWndCtl, &r1) || !GetClientRect(hWndParent, &r2))
      goto cleanup;

    MapWindowPoints(HWND_DESKTOP, hWndParent, (LPPOINT)&r1, 2);
      
    g_margins.cxLeftWidth = g_margins.cxRightWidth = g_margins.cyTopHeight = 0;
    g_margins.cyBottomHeight = r2.bottom - r1.bottom;
    g_rectAero.left = g_rectWindow.left = 0;
    g_rectAero.top = r1.bottom; g_rectWindow.top = 0;
    g_rectAero.right = g_rectWindow.right = r2.right;
    g_rectAero.bottom = r2.bottom; g_rectWindow.bottom = r1.bottom;
      
    if (fAero)
    {
      ShowWindow(hWndCtl, SW_HIDE);
      ShowWindow(hWndBrandingText, SW_HIDE);
    }
  }

  // Apply Windows Aero.
  if (fAero)
  {
    if (!SUCCEEDED(DwmExtendFrameIntoClientArea(hWndParent, &g_margins)))
      goto cleanup;
    g_hbAero = CreateSolidBrush(COLOR_AERO);
  }
  else
  {
    g_hbAero = NULL;
  }

  // Register callback so /NOUNLOAD does not have to be used.
  extra->RegisterPluginCallback((HMODULE)g_hInstance, PluginCallback);

  // Get branding text pos.
  if (g_pwcBrandingText != NULL)
  {
    g_iBrandingLeft = 0;
    RECT r;
    if (GetWindowRect(hWndBrandingText, &r))
    {
      MapWindowPoints(HWND_DESKTOP, hWndParent, (LPPOINT)&r, 1);
      g_iBrandingLeft = r.left;
    }
  }

  // We need to handle WM_ERASEBKGND to fill our aero rect and non aero
  // rect.
  ParentDlgProcOld = (WNDPROC)SetWindowLongPtr(hWndParent, DWLP_DLGPROC, (LONG)ParentDlgProc);

  // Subclass the buttons.
  g_hBack = GetDlgItem(hWndParent, 3);
  SetProp(g_hBack, PROP_BUTTON_WNDPROC, (HANDLE)SetWindowLongPtr(g_hBack, GWLP_WNDPROC, (LONG)ButtonWndProc));
  g_hCancel = GetDlgItem(hWndParent, 2);
  SetProp(g_hCancel, PROP_BUTTON_WNDPROC, (HANDLE)SetWindowLongPtr(g_hCancel, GWLP_WNDPROC, (LONG)ButtonWndProc));
  g_hNext = GetDlgItem(hWndParent, 1);
  SetProp(g_hNext, PROP_BUTTON_WNDPROC, (HANDLE)SetWindowLongPtr(g_hNext, GWLP_WNDPROC, (LONG)ButtonWndProc));

  return;
cleanup:

  if (pszParam != NULL)
    GlobalFree(pszParam);
  
#ifndef UNICODE
  if (g_pwcBrandingText != NULL)
    GlobalFree(g_pwcBrandingText);
#endif

  CloseThemeData(g_hButtonTheme);

  if (g_hWindowTheme != NULL)
    CloseThemeData(g_hWindowTheme);

  BufferedPaintUnInit();
}

BOOL WINAPI DllMain(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
  g_hInstance = hInst;
  return TRUE;
}