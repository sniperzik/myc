Aero NSIS plug-in

Author:  Stuart 'Afrow UK' Welch
Company: Afrow Soft Ltd
Date:    1st July 2011
Version: 1.0.0.4

Enables Windows Aero glass effect on NSIS UI. The effect is only
available on Vista/7 and above, and when aero is enabled.

See Examples\Aero\*.

------------------------------------------------------------------------
Usage (Modern UI)
------------------------------------------------------------------------

  !define MUI_CUSTOMFUNCTION_GUIINIT onGUIInit
  (insert pages & languages here)
  Function onGUIInit
    Aero::Apply [Options]
  FunctionEnd

------------------------------------------------------------------------
Usage (Classic UI)
------------------------------------------------------------------------

  Function .onGUIInit
    Aero::Apply [Options]
  FunctionEnd

------------------------------------------------------------------------
Options
------------------------------------------------------------------------

  /nobranding

  Do not draw any branding text.

------------------------------------------------------------------------
Change Log
------------------------------------------------------------------------

1.0.0.4 - 1st July 2011
* Fixed transparent button text in some situations for Next/Back/Cancel
  buttons.

1.0.0.3 - 19th May 2011
* Now always uses GetWindowTextW for the branding text (as
  DrawThemeTextEx is Unicode only).

1.0.0.2 - 4th May 2011
* Fixed typo Window -> CompositedWindow::Window in WM_THEMECHANGED
  (thanks Anders).
* No longer uses layered window drawing when branding text isn't used
  (aero hack to avoid owner-drawing buttons, but may not work on Vista).
* Now uses theme text colour for branding text (but still original
  font).
* Improved fall-back drawing if DWM composition is disabled (all drawing
  then handled by Windows/NSIS).
* Now re-shows old branding text and horizontal ruler when DWM
  composition is disabled.
* Plug-in now loads even if DWM composition is disabled, but could be
  enabled.
* Now only handles WM_CTLCOLORBTN for the Back, Next and Cancel buttons.
* Now uses GetThemeBackgroundContentRect to determine the button area
  to draw opaque.

1.0.0.1 - 28th April 2011
* Now gets text glow size from current theme (12 by default).
* Used double buffered painting to fix button text transparency (only
  occurred on some machines).

1.0.0.0 - 24th April 2011
* First version.

------------------------------------------------------------------------
License
------------------------------------------------------------------------

This plug-in is provided 'as-is', without any express or implied
warranty. In no event will the author be held liable for any damages
arising from the use of this plug-in.

Permission is granted to anyone to use this plug-in for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this plug-in must not be misrepresented; you must not
   claim that you wrote the original plug-in.
   If you use this plug-in in a product, an acknowledgment in the
   product documentation would be appreciated but is not required.
2. Altered versions must be plainly marked as such, and must not be
   misrepresented as being the original plug-in.
3. This notice may not be removed or altered from any distribution.