﻿	
	##########################################
	###
	###   PLEASE BACKUP YOUR CONFIG FILE OR
	###   OTHER CSGO SPECIFICATIONS
	###   
	###   SAVE YOUR SCRIPTS AND MODIFICATIONS!!!
	###
	##########################################
	
	
	This installation adds to your cs better configs and specifications.
	
		Simple, useful and effective configs for Counter-Strike Global Offensive
			
	--- How To Install
	
		Install in full Counter-Strike Global Offensive folder as patch!
	
	--- Binds
	
		Press F1 for CZ75-Auto/Tec9 + def
		Press F2 for M4a1/Ak47 + vest, def
		Press F3 for Famas/Galil + vest, def
		Press F4 for Eco&Granades + he, mol, inc, fl, sm, def, decoy
		Press F6 for Default AutoBuy.
		Press F9 or write R in Console to Reload MyC Config.
		Press X to say_team C4 here with radio msg.		
		Write D in Console to easy disconnect from your current server.
		Write MICON or MICOFF in Console to easy enable or disable microphone bind to a F key.
		Add Your Scripts in csgo/cfg/MyC_cfg/Engine_User.cfg
	
	--- Configs status
	
	//////////////////////////////
	///   MyC Core
	//////////////////////////////
	- MyC Cleaner
	- High FPS Configs
	- SetLaunchOptions.txt for Steam
	- I-Net Connection Configs
		+ C4 Located Script
		+ Buy Script
		+ Disconnect Alias
		+ Microphone Alias
	
	--- Included
	
	- File Backups
	- Uninstaller
	- MyC Updater

	--- Author: Sn^
	--- http://www.Myc.Lv
	
